// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase:
  {
    apiKey: "AIzaSyB8Y3x7hw2RjIvLdWtZDewtm_X2UJ8-e30",
    authDomain: "fstore-1fda9.firebaseapp.com",
    databaseURL: "https://fstore-1fda9.firebaseio.com",
    projectId: "fstore-1fda9",
    storageBucket: "fstore-1fda9.appspot.com",
    messagingSenderId: "999457109851"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
