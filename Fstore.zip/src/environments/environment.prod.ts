export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyB8Y3x7hw2RjIvLdWtZDewtm_X2UJ8-e30",
    authDomain: "fstore-1fda9.firebaseapp.com",
    databaseURL: "https://fstore-1fda9.firebaseio.com",
    projectId: "fstore-1fda9",
    storageBucket: "fstore-1fda9.appspot.com",
    messagingSenderId: "999457109851"
  }
};
