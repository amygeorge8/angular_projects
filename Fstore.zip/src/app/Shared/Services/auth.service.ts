import * as firebase from 'firebase';
import { AppUser } from './../Models/app-user';
import { UserService } from 'shared/Services/user.service';
import { AngularFireAuth } from '@angular/fire/auth';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})

/*Class to implement Authentication - login/logout methods
Used --> Firebase Google Authentication
--get logged in username*/

export class AuthService {
 
  user$:Observable<firebase.User>;
 
  constructor(
    private userService:UserService,
    private afAuth:AngularFireAuth,private route:ActivatedRoute) { 
    this.user$ = afAuth.authState;
  }

  login(){
    let returnurl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
    localStorage.setItem('returnUrl',returnurl);
    this.afAuth.auth.signInWithRedirect(new firebase.auth.GoogleAuthProvider());
  }
  
  logout(){
    this.afAuth.auth.signOut();
  }

  get appUser$(): Observable<AppUser>{
    return this.user$.pipe(switchMap(user => {
      if(user) return this.userService.get(user.uid);
          return of(null);
      }));
    }
  }
