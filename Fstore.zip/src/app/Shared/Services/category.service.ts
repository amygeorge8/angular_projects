import { AngularFireDatabase } from '@angular/fire/database';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
//getting all categories from db

export class CategoryService {

  constructor(private db : AngularFireDatabase) { }
  
  getall(){
    return this.db.list('category');
  }
  
}
