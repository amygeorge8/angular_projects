import { AngularFireDatabase } from '@angular/fire/database';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

//store and retrieve product details

export class ProductService {
  constructor(private db:AngularFireDatabase) { }
  
  //Add a new Item
  create(product) {
    return this.db.list('/products').push(product);
  }

  //retrieve all products
  getall(){
    return this.db.list('/products');
  }

  //retrieve selected product details
  get(productId){
   return this.db.object('/products/'+productId);
  }

  //update existing product
  update(productId,product) {
    return this.db.object('/products/'+productId).update(product);
  }

  //delete existing product
  delete(productId){
    return this.db.object('/products/'+productId).remove();
  }

}
