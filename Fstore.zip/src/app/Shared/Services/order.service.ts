import { AngularFireDatabase } from '@angular/fire/database';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

//store and retrieve order details

export class OrderService {

  constructor(private db: AngularFireDatabase) {}
  
  storeOrder(order){
     console.log("storing Order")
     return this.db.list('/orders').push(order);
   }

   getOrders(){
     return this.db.list('/orders');
   }

   //retrieve order history of the logged-in user
   getOrdersByUser(userId: string) {
    return this.db.list('/orders',ref => ref.orderByChild('userId').equalTo(userId));
  }
}
