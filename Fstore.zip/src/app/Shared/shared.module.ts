import { DataTableModule } from 'angular-6-datatable';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './../app-routing.module';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AuthService } from 'shared/Services/auth.service';
import { CategoryService } from 'shared/Services/category.service';
import { OrderService } from 'shared/Services/order.service';
import { ProductService } from 'shared/Services/product.service';
import { UserService } from 'shared/Services/user.service';
import { ProductCardComponent } from './Components/product-card/product-card.component';
import { AuthGuard } from './Services/auth-guard.service';

@NgModule({
  declarations: [
    ProductCardComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule,
    NgbModule.forRoot(),
    AngularFireAuthModule,
    AngularFireDatabaseModule,
    DataTableModule
  ],
  exports: [
    CommonModule,
    ProductCardComponent,
    AppRoutingModule,
    FormsModule,
    NgbModule.forRoot().ngModule,
    AngularFireAuthModule,
    AngularFireDatabaseModule,
    DataTableModule
  ],
  providers:[
    AuthService,
    AuthGuard,
    UserService,
    ProductService,
    CategoryService,
    OrderService
  ]
})
export class SharedModule { }
