import { AuthService } from 'shared/Services/auth.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
//login class
export class LoginComponent {

  constructor(private auth:AuthService) { }
  
  login(){
   this.auth.login();
  }


}
