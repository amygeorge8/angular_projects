import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { OrderService } from 'shared/Services/order.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'admin-orders',
  templateUrl: './admin-orders.component.html',
  styleUrls: ['./admin-orders.component.css']
})

//implement admin-view of all successful orders
export class AdminOrdersComponent  {

  orders$;
  
  constructor(private orderService: OrderService) { 
  this.orders$ = this.orderService.getOrders().snapshotChanges().pipe(map(items=>{
      return items.map(a=>{
        return a.payload.val();
       });
      }
   ));
  }
}
