
import { ProductService } from 'shared/Services/product.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';


@Component({
  selector: 'app-admin-products',
  templateUrl: './admin-products.component.html',
  styleUrls: ['./admin-products.component.css']
})

//class for Admin- view product data
export class AdminProductsComponent implements OnDestroy {
 product$ : any[];
 filteredProducts :any[];
 subscription: Subscription;
 
 //retrieving filtered products
 constructor(private productservice :ProductService) {
  this.subscription = this.productservice.getall().snapshotChanges()
  .subscribe(product$ =>this.filteredProducts = this.product$ = product$
  .map(a =>({id:a.payload.key,...a.payload.val()})));
  }

  //filtering logic
   filter(query:string)
   {
     this.filteredProducts = (query)?
     this.product$.filter(p =>p.title.toLowerCase().includes(query.toLowerCase())) : 
     this.product$;
   }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}


