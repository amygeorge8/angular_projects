import { AuthService } from 'shared/Services/auth.service';
import { OrderService } from 'shared/Services/order.service';
import { take } from 'rxjs/operators';
import { ProductService } from 'shared/Services/product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})

//check-out class for order placing
export class CheckOutComponent{

  shipping = {}; 
  id : string;
  product:Object={};
  UserId : string;

  //constructor to get product details
  constructor(private productService : ProductService,
  private route: ActivatedRoute,
  private orderService: OrderService,
  private authService : AuthService,
  private router :Router){
      this.id = this.route.snapshot.paramMap.get('id');
      if(this.id) 
      this.productService.get(this.id).valueChanges().pipe(take(1)).subscribe(p =>this.product = p);
      this.authService.user$.pipe(take(1)).subscribe(user => this.UserId = user.uid);
  }
  
  //create order object &storing to firebase
  placeOrder() {
    let order ={
      userId : this.UserId,
      datePlaced: new Date().getTime(),
      shipping: this.shipping,
      product: this.product
      }
    let result  =this.orderService.storeOrder(order);
    this.router.navigate(['/order-success',result.key]);
  } 


}
