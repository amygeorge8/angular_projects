import { AuthService } from 'shared/Services/auth.service';
import { switchMap } from 'rxjs/operators';
import { OrderService } from 'shared/Services/order.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})

//to render users order history
export class MyOrdersComponent {
  orders$;
  
  //constror retrieving order history
  constructor(
    private authService: AuthService,
    private orderService: OrderService) { 
    this.orders$ = authService.user$.pipe(switchMap(u => orderService.getOrdersByUser(u.uid).valueChanges()));
  }

}
