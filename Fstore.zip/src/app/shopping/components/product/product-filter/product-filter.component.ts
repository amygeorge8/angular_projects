import { map } from 'rxjs/operators';
import { CategoryService } from 'shared/Services/category.service';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'product-filter',
  templateUrl: './product-filter.component.html',
  styleUrls: ['./product-filter.component.css']
})

//class for product-category filtering
export class ProductFilterComponent {

  categories$;
  @Input('category') category ;

  constructor(categoryservice :CategoryService) {
    this.categories$ = categoryservice.getall().snapshotChanges().pipe(map(c=>{
      return c.map(a => ({
        id: a.payload.key,...a.payload.val()
      }))
    }))
   }

}
