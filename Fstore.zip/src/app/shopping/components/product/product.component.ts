
import { Subscription,Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from 'shared/Services/product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

//rendering product-cards -current home page
export class ProductComponent {
  
  product$ : any[];
  filteredProducts : any[];
  category:string;
  subscription: Subscription;
  cart: any

  //constructor retrieving product details
  constructor(
    productService : ProductService,
    route:ActivatedRoute) { 
    this.subscription = productService.getall().snapshotChanges()
    .subscribe(product$ => {
    this.product$ = product$.map(a =>({id:a.payload.key,...a.payload.val()}));
    route.queryParamMap.subscribe( params =>
      {
        this.category = params.get('category');
        this.filteredProducts = (this.category)?
        this.product$.filter(p=>p.category.toLowerCase().includes(this.category.toLowerCase())):
        this.product$;
      });
    });
  }

  //filtering based on category
  filter(query:string){
    this.filteredProducts = (query)?
    this.product$.filter(p =>p.title.toLowerCase().includes(query.toLowerCase())) : 
    this.product$;
  }  
}

 

