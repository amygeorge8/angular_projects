import { SharedModule } from './../Shared/shared.module';
import { ProductFilterComponent } from './components/product/product-filter/product-filter.component';
import { ProductComponent } from './components/product/product.component';
import { OrderSuccessComponent } from './components/order-success/order-success.component';
import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { CheckOutComponent } from './components/check-out/check-out.component';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [
    CheckOutComponent,
    MyOrdersComponent,
    OrderSuccessComponent,
    ProductFilterComponent,
    ProductComponent
  ],
  imports: [
    SharedModule
  ],
  exports:[
    ProductComponent
  ]
  
})
export class ShoppingModule {}
